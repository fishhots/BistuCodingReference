package cn.campsg.practical.bubble;


public class MainClass{

	public static void main(String[] args) {
		
		MainForm.show(args);
	
	}

}